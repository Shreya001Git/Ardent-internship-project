/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.library;

/**
 *
 * @author Shreya Chakravarty
 */
class ex {

    static int days;
    static int days1;
    
}
