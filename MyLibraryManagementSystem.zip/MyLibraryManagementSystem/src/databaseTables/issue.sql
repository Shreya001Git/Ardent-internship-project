-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2021 at 01:04 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lmsproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `Book_ID` int(10) DEFAULT NULL,
  `Book_Name` varchar(100) NOT NULL,
  `Student_ID` varchar(10) NOT NULL,
  `Student_Name` varchar(100) NOT NULL,
  `Course_Name` varchar(6) NOT NULL,
  `Branch_Name` varchar(10) NOT NULL,
  `Semester` varchar(3) NOT NULL,
  `Contact_No` varchar(10) NOT NULL,
  `Issue_Date` varchar(10) NOT NULL,
  `Due_Date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue`
--

INSERT INTO `issue` (`Book_ID`, `Book_Name`, `Student_ID`, `Student_Name`, `Course_Name`, `Branch_Name`, `Semester`, `Contact_No`, `Issue_Date`, `Due_Date`) VALUES
(12, 'Signals and System', '80', 'Sagar Kumar', 'B.Tech', 'Mechanical', '1st', '8093213654', '30-08-2021', '04-09-2021'),
(16, 'Electronic Devices', '101', 'Suman Roy', 'B.Tech', 'IT', '5th', '8905467894', '30-08-2021', '02-08-2021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `issue`
--
ALTER TABLE `issue`
  ADD KEY `Book_ID` (`Book_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `issue`
--
ALTER TABLE `issue`
  ADD CONSTRAINT `issue_ibfk_1` FOREIGN KEY (`Book_ID`) REFERENCES `newbook` (`Book_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
