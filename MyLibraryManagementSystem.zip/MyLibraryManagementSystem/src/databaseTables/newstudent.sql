-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2021 at 01:07 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lmsproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `newstudent`
--

CREATE TABLE `newstudent` (
  `Student_ID` varchar(10) NOT NULL,
  `Student_Name` varchar(100) NOT NULL,
  `Course_Name` varchar(6) NOT NULL,
  `Branch_Name` varchar(10) NOT NULL,
  `Semester` varchar(3) NOT NULL,
  `Contact_No` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newstudent`
--

INSERT INTO `newstudent` (`Student_ID`, `Student_Name`, `Course_Name`, `Branch_Name`, `Semester`, `Contact_No`) VALUES
('101', 'Suman Roy', 'B.Tech', 'IT', '5th', '8905467894'),
('132', 'Puja Gupta', 'B.Tech', 'IT', '7th', '9883238145'),
('135', 'Ritam Sen', 'B.Tech', 'Electrical', '5th', '9339738145'),
('56', 'Damini Dutta', 'B.Tech', 'Electrical', '1st', '9123356780'),
('67', 'Rahul Sinha', 'B.Tech', 'ECE', '7th', '9147483647'),
('76', 'Ahana Mitra', 'B.Tech', 'CSE', '3rd', '7980407622'),
('80', 'Sagar Kumar', 'B.Tech', 'Mechanical', '1st', '8093213654'),
('86', 'Sneha Roy', 'B.Tech', 'ECE', '5th', '9157483640'),
('89', 'Sneha', 'B.Tech', 'IT', '5th', '9005734212'),
('93', 'Ayush Sen', 'B.Tech', 'CSE', '7th', '6247483647');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `newstudent`
--
ALTER TABLE `newstudent`
  ADD PRIMARY KEY (`Student_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
