-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2021 at 01:05 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lmsproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `newbook`
--

CREATE TABLE `newbook` (
  `Book_ID` int(10) NOT NULL,
  `Book_Name` varchar(100) NOT NULL,
  `Author` varchar(100) NOT NULL,
  `Publisher` varchar(100) NOT NULL,
  `Year_of_Publication` varchar(4) NOT NULL,
  `Quantity` int(10) NOT NULL,
  `Issued` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newbook`
--

INSERT INTO `newbook` (`Book_ID`, `Book_Name`, `Author`, `Publisher`, `Year_of_Publication`, `Quantity`, `Issued`) VALUES
(1, 'Numerical Concepts', 'D.N.Sharma', 'Roohi Books', '2017', 10, 0),
(2, 'Introduction to Programming', 'Bhaskar Roy', 'Tech Books', '2019', 20, 0),
(3, 'Network Theory', 'K.L Rakshit', 'Chatterjee Publications', '2020', 15, 0),
(4, 'Basic Electrical', 'Dutta & Sen', 'Sondhay Publishers', '2015', 17, 0),
(5, 'Ethics', 'G.Krishna', 'Eclipse publishers', '2017', 10, 0),
(6, 'Java Programming', 'R.Stevens', 'Time publications', '2020', 9, 0),
(7, 'Engineering Maths', 'R.D.Sharma', 'Roohi Publishers', '2018', 12, 0),
(8, 'C for Beginners', 'N.Peters', 'Time publications', '2020', 7, 0),
(9, 'Analog Circuits', 'K.L Rakshit', 'Sondhay publishers', '2018', 10, 0),
(10, 'ABC of Communication', 'R.Stevenson', 'Eclipse publication', '2019', 8, 0),
(11, 'Data Structures', 'D.N Rogers', 'Eclipse publications', '2016', 7, 0),
(12, 'Signals and System', 'P. Ramesh Babu', 'Scitech Publishers', '2018', 15, 0),
(13, 'DSA', 'T.Marley', 'Technocrat publishers', '2020', 20, 0),
(14, 'Basic C Programming', 'S.K.Raman', 'Haravard publishers', '2019', 8, 0),
(15, 'C Programming', 'R.Richads', 'Time Publishers', '2020', 9, 0),
(16, 'Electronic Devices', 'DP Dey', 'Technocrat publishers', '2018', 15, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `newbook`
--
ALTER TABLE `newbook`
  ADD PRIMARY KEY (`Book_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `newbook`
--
ALTER TABLE `newbook`
  MODIFY `Book_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
